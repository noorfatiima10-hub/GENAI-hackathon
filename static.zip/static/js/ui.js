function syncSlider(el) {
  const targetId = el.dataset.sliderTarget;
  const barId = el.dataset.sliderBar;
  const max = Number(el.dataset.sliderMax || 100);
  const suffix = el.dataset.sliderSuffix || '';
  const valueTarget = targetId ? document.getElementById(targetId) : null;
  const barTarget = barId ? document.getElementById(barId) : null;
  if (valueTarget) valueTarget.textContent = `${el.value}${suffix}`;
  if (barTarget) barTarget.style.width = `${(Number(el.value) / max) * 100}%`;
}

function initPasswordToggles() {
  document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const inputId = btn.getAttribute('data-toggle-password');
      const input = document.getElementById(inputId);
      if (!input) return;
      const nextType = input.type === 'password' ? 'text' : 'password';
      input.type = nextType;
      btn.textContent = nextType === 'password' ? '👁' : '🙈';
    });
  });
}

function initNavActiveState() {
  const currentPath = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach((link) => {
    const href = link.getAttribute('href');
    if (href && href !== '/' && currentPath.startsWith(href)) {
      link.classList.add('active');
    }
    if (href === '/' && currentPath === '/') {
      link.classList.add('active');
    }
  });
}

function initSliders() {
  document.querySelectorAll('[data-slider-target]').forEach((slider) => {
    syncSlider(slider);
    slider.addEventListener('input', () => syncSlider(slider));
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initNavActiveState();
  initPasswordToggles();
  initSliders();
});
