function avg(arr) {
  if (!arr || !arr.length) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function peakHour(arr) {
  if (!arr || !arr.length) return 0;
  let bestIndex = 0;
  arr.forEach((value, index) => {
    if (value > arr[bestIndex]) bestIndex = index;
  });
  return bestIndex;
}

function labels24() {
  return Array.from({ length: 24 }, (_, i) => i);
}

function traitDescription(type) {
  const map = {
    'Base Self': 'Most balanced option across the day. Good for steady output and sustainable routines.',
    'Bold Self': 'Stronger for action-heavy or public-facing days with more social momentum.',
    'Introverted Self': 'Best for quiet concentration, solo work, and deep focus protection.',
    'Creative Self': 'Useful for ideation, experimentation, and flexible problem solving.'
  };
  return map[type] || 'A projected version of your current profile.';
}

function datasetFor(label, dataArr, index) {
  const borderPalette = [
    'rgba(121, 179, 255, 1)',
    'rgba(120, 235, 193, 1)',
    'rgba(255, 182, 84, 1)',
    'rgba(182, 145, 255, 1)'
  ];

  return {
    label,
    data: dataArr,
    tension: 0.35,
    pointRadius: 0,
    borderWidth: 2,
    fill: false,
    borderColor: borderPalette[index % borderPalette.length],
    backgroundColor: borderPalette[index % borderPalette.length]
  };
}

function chartThemeOptions(label) {
  const styles = getComputedStyle(document.documentElement);
  const textColor = styles.getPropertyValue('--muted').trim() || '#94a3b8';
  const gridColor = document.documentElement.getAttribute('data-bs-theme') === 'light' ? 'rgba(16,33,61,.08)' : 'rgba(255,255,255,.06)';
  return {
    textColor,
    scales: {
      x: { ticks: { color: textColor }, grid: { color: gridColor }, title: { display: true, text: 'Hour of day', color: textColor } },
      y: { ticks: { color: textColor }, grid: { color: gridColor }, min: 0, max: 100, title: { display: true, text: label, color: textColor } }
    },
    plugins: { legend: { labels: { color: textColor } }, tooltip: { mode: 'index', intersect: false } }
  };
}

function buildChart(canvasId, metricKey, label) {
  const ctx = document.getElementById(canvasId);
  if (!ctx || !window.selves) return null;
  const datasets = window.selves.map((s, index) => datasetFor(s.type, s.day[metricKey], index));
  const theme = chartThemeOptions(label);

  return new Chart(ctx, {
    type: 'line',
    data: { labels: labels24(), datasets },
    options: {
      responsive: true,
      plugins: theme.plugins,
      interaction: { mode: 'index', intersect: false },
      scales: theme.scales,
    }
  });
}

function renderTimeline() {
  const timeline = document.getElementById('timeline');
  const selector = document.getElementById('selfSelect');
  if (!timeline || !selector || !window.selves || !window.selves.length) return;

  const selected = window.selves[parseInt(selector.value || '0', 10)] || window.selves[0];
  timeline.innerHTML = (selected.day.blocks || [])
    .map((block) => `
      <div class="timeline-row">
        <div class="timeline-meta">
          <strong>${block.label}</strong>
          <span class="text-muted-premium">${String(block.start).padStart(2, '0')}:00 - ${String(block.end).padStart(2, '0')}:00</span>
        </div>
        <div class="timeline-bar"><span style="width:${Math.round((block.intensity || 0) * 100)}%"></span></div>
      </div>`)
    .join('');
}

function renderPersonalityCards() {
  const container = document.getElementById('personalityCards');
  if (!container || !window.selves) return;

  const enriched = window.selves.map((s) => {
    const energy = avg(s.day.energy);
    const focus = avg(s.day.focus);
    const social = avg(s.day.social);
    return {
      ...s,
      avgEnergy: energy,
      avgFocus: focus,
      avgSocial: social,
      score: energy * 0.35 + focus * 0.4 + social * 0.25,
      peak: peakHour(s.day.energy)
    };
  });

  container.innerHTML = enriched
    .map((s) => {
      const icon = s.type.includes('Bold') ? '🚀' : s.type.includes('Introverted') ? '🎯' : s.type.includes('Creative') ? '✨' : '⚖️';
      return `
        <div class="personality-card">
          <div class="personality-icon">${icon}</div>
          <h5 class="section-title mb-2">${s.type}</h5>
          <p class="text-muted-premium mb-3">${traitDescription(s.type)}</p>
          <div class="recommendation-list">
            <div class="recommendation-item"><strong>Avg energy:</strong> ${s.avgEnergy.toFixed(1)}</div>
            <div class="recommendation-item"><strong>Avg focus:</strong> ${s.avgFocus.toFixed(1)}</div>
            <div class="recommendation-item"><strong>Avg social:</strong> ${s.avgSocial.toFixed(1)}</div>
            <div class="recommendation-item"><strong>Peak hour:</strong> ${String(s.peak).padStart(2, '0')}:00</div>
          </div>
        </div>`;
    })
    .join('');
}

function renderRunCharts() {
  if (!window.selves || !window.selves.length) return;
  if (window.dailyEnergyChart) window.dailyEnergyChart.destroy();
  if (window.dailyFocusChart) window.dailyFocusChart.destroy();
  window.dailyEnergyChart = buildChart('dailyEnergy', 'energy', 'Energy');
  window.dailyFocusChart = buildChart('dailyFocus', 'focus', 'Focus');
  renderTimeline();
}

document.addEventListener('DOMContentLoaded', () => {
  if (!window.selves || !window.selves.length) return;
  renderRunCharts();
  renderPersonalityCards();
  const selector = document.getElementById('selfSelect');
  if (selector) selector.addEventListener('change', renderTimeline);
});

window.addEventListener('theme:changed', () => {
  if (!window.selves || !window.selves.length) return;
  renderRunCharts();
});
