function escapeHtml(value) {
  return String(value || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function scrollChatToBottom() {
  const box = document.getElementById('chatMessages');
  if (box) box.scrollTop = box.scrollHeight;
}

function addChatBubble(role, html, meta, extraClass = '') {
  const box = document.getElementById('chatMessages');
  if (!box) return;
  const empty = document.getElementById('chatEmptyState');
  if (empty) empty.remove();
  const wrapper = document.createElement('div');
  wrapper.className = `chat-bubble ${role === 'user' ? 'chat-bubble-user' : 'chat-bubble-ai'} ${extraClass}`.trim();
  wrapper.innerHTML = `
    <div class="chat-meta">${escapeHtml(meta)}</div>
    <div class="markdown-body">${html}</div>
  `;
  box.appendChild(wrapper);
  scrollChatToBottom();
  return wrapper;
}

function setChatLoading(isLoading) {
  const btn = document.getElementById('chatSendBtn');
  const input = document.getElementById('chatInput');
  if (btn) {
    btn.disabled = isLoading;
    btn.textContent = isLoading ? 'Thinking...' : 'Send message';
  }
  if (input) input.disabled = isLoading;
}

async function sendMessage(message) {
  const safeText = escapeHtml(message).replaceAll('\n', '<br>');
  addChatBubble('user', `<p>${safeText}</p>`, 'You • now');
  const thinking = addChatBubble('assistant', '<p class="typing-dots"><span></span><span></span><span></span></p>', 'Parallel Self AI • thinking', 'chat-loading');

  const response = await fetch('/assistant/api', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  });

  const data = await response.json().catch(() => null);
  if (thinking) thinking.remove();

  if (!response.ok || !data || !data.ok) {
    addChatBubble('assistant', `<p>${escapeHtml((data && data.error) || 'Something went wrong.')}</p>`, 'Parallel Self AI • error');
    return;
  }

  const badge = data.assistant.live ? `Live Groq • ${data.assistant.model}` : `${data.assistant.model}`;
  addChatBubble('assistant', data.assistant.html, `Parallel Self AI • ${badge}`);
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');
  const count = document.getElementById('chatCount');
  scrollChatToBottom();

  if (input && count) {
    const updateCount = () => { count.textContent = String(input.value.length); };
    input.addEventListener('input', updateCount);
    updateCount();
  }

  document.querySelectorAll('[data-prompt]').forEach((chip) => {
    chip.addEventListener('click', () => {
      if (!input) return;
      input.value = chip.getAttribute('data-prompt') || '';
      input.focus();
      input.dispatchEvent(new Event('input'));
    });
  });

  if (form && input) {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const message = input.value.trim();
      if (!message) return;
      input.value = '';
      input.dispatchEvent(new Event('input'));
      setChatLoading(true);
      try {
        await sendMessage(message);
      } catch (error) {
        addChatBubble('assistant', `<p>Network error: ${escapeHtml(error.message || error)}</p>`, 'Parallel Self AI • error');
      } finally {
        setChatLoading(false);
        input.focus();
      }
    });
  }
});
