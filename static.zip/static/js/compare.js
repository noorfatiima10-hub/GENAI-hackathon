function avg(arr) {
  if (!arr || !arr.length) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function peakHour(arr) {
  if (!arr || !arr.length) return 0;
  let idx = 0;
  arr.forEach((v, i) => { if (v > arr[idx]) idx = i; });
  return idx;
}

function colorFor(index, alpha) {
  const palette = [
    `rgba(121,179,255,${alpha})`,
    `rgba(120,235,193,${alpha})`,
    `rgba(255,182,84,${alpha})`,
    `rgba(182,145,255,${alpha})`
  ];
  return palette[index % palette.length];
}

function themeTextColor() {
  return getComputedStyle(document.documentElement).getPropertyValue('--muted').trim() || '#94a3b8';
}

function themeGridColor() {
  return document.documentElement.getAttribute('data-bs-theme') === 'light' ? 'rgba(16,33,61,.08)' : 'rgba(255,255,255,.06)';
}

function buildRows() {
  return window.selves.map((s) => ({
    ...s,
    avgEnergy: avg(s.day.energy),
    avgFocus: avg(s.day.focus),
    avgSocial: avg(s.day.social),
    peak: peakHour(s.day.energy)
  })).map((row) => ({ ...row, score: row.avgEnergy * 0.4 + row.avgFocus * 0.4 + row.avgSocial * 0.2 }));
}

function renderCompareCharts() {
  if (!window.selves || !window.selves.length) return;
  const rows = buildRows();
  const labels = window.selves.map((s) => s.type);
  const textColor = themeTextColor();
  const gridColor = themeGridColor();

  if (window.avgBarsChart) window.avgBarsChart.destroy();
  if (window.energyOverlayChart) window.energyOverlayChart.destroy();

  const avgBars = document.getElementById('avgBars');
  if (avgBars) {
    window.avgBarsChart = new Chart(avgBars, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Avg Energy', data: rows.map((r) => r.avgEnergy), backgroundColor: colorFor(0, 0.6), borderColor: colorFor(0, 1), borderWidth: 1, borderRadius: 10 },
          { label: 'Avg Focus', data: rows.map((r) => r.avgFocus), backgroundColor: colorFor(1, 0.6), borderColor: colorFor(1, 1), borderWidth: 1, borderRadius: 10 },
          { label: 'Avg Social', data: rows.map((r) => r.avgSocial), backgroundColor: colorFor(2, 0.6), borderColor: colorFor(2, 1), borderWidth: 1, borderRadius: 10 }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { labels: { color: textColor } } },
        scales: {
          x: { ticks: { color: textColor }, grid: { color: gridColor } },
          y: { ticks: { color: textColor }, grid: { color: gridColor }, min: 0, max: 100 }
        }
      }
    });
  }

  const energyOverlay = document.getElementById('energyOverlay');
  if (energyOverlay) {
    window.energyOverlayChart = new Chart(energyOverlay, {
      type: 'line',
      data: {
        labels: Array.from({ length: 24 }, (_, i) => i),
        datasets: rows.map((row, index) => ({
          label: row.type,
          data: row.day.energy,
          tension: 0.35,
          pointRadius: 0,
          borderWidth: 2,
          borderColor: colorFor(index, 1),
          backgroundColor: colorFor(index, 0.18)
        }))
      },
      options: {
        responsive: true,
        plugins: { legend: { labels: { color: textColor } } },
        scales: {
          x: { ticks: { color: textColor }, grid: { color: gridColor } },
          y: { ticks: { color: textColor }, grid: { color: gridColor }, min: 0, max: 100 }
        }
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', renderCompareCharts);
window.addEventListener('theme:changed', renderCompareCharts);
